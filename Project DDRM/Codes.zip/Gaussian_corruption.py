# This code was written to degrade the image and store it in a certain place,
# Which will be used by the gaussian_diffusion.py file during sampling

import numpy as np
import matplotlib.pyplot as plt

import os
from PIL import Image
import matplotlib.pyplot as plt
from torchvision import transforms
import torch
import torch.fft
import torch.nn.functional as F


def fftshift2d(x):
    h, w = x.shape
    return torch.roll(torch.roll(x, shifts=h//2, dims=0), shifts=w//2, dims=1)

def degrade_with_blur(x0, kernel_size=11, sigma=3.0, noise_std=0.01, eps=1e-5):
    C, H, W = x0.shape
    device = x0.device

    x = torch.linspace(-3, 3, steps=kernel_size, device=device)
    gauss = torch.exp(-x**2 / (2 * sigma**2))
    gauss /= gauss.sum()
    kernel2d = torch.outer(gauss, gauss)
    kernel2d /= kernel2d.sum()  

    pad_h = H - kernel_size
    pad_w = W - kernel_size
    kernel_padded = F.pad(kernel2d, (pad_w // 2, pad_w - pad_w // 2,
                                     pad_h // 2, pad_h - pad_h // 2))
    kernel_padded = kernel_padded.to(device)  # (H, W)

    kernel_centered = fftshift2d(kernel_padded)
    h_fft = torch.fft.fft2(kernel_centered) 

    x0_fft = torch.fft.fft2(x0)             
    h_fft_bc = h_fft.unsqueeze(0).expand(C, H, W) 
    y_fft = x0_fft * h_fft_bc               
    y = torch.fft.ifft2(y_fft).real.clamp(0, 1) 

    noise = torch.randn_like(y) * noise_std
    y_noisy = (y + noise).clamp(0, 1)

    y_bar = torch.fft.fft2(y_noisy)

    return y_noisy, y_bar, h_fft

# Processing images from Imagenet directory

image_folder = "/home/gmv4/ddrm/exp/datasets/imagenet/imagenet"

image_paths = [
    os.path.join(image_folder, fname)
    for fname in os.listdir(image_folder)
    if fname.lower().endswith((".jpeg", ".jpg"))
]
indices = np.random.randint(0,high=999,size=2)
print(indices)
image_paths = [ sorted(image_paths)[ind] for ind in indices ]

transform = transforms.Compose([
    transforms.Resize((256, 256)),
    transforms.ToTensor(),
])

plt.figure(figsize=(16, 4))
for i, path in enumerate(image_paths):
    img = Image.open(path).convert("RGB")
    img_tensor = transform(img)
    plt.subplot(1, len(image_paths), i + 1)
    plt.imshow(img_tensor.permute(1, 2, 0))
    plt.title(f"Sample {i}")
    plt.axis("off")

plt.tight_layout()
plt.show()

# Gaussian Blur Degradation + additive noise (z)
y_noisy, y_bar, h_fft = degrade_with_blur(img_tensor, noise_std=0.02)

plt.imshow(y_noisy.permute(1,2,0))
plt.axis("off")
plt.show()